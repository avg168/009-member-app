package global.zerozero9.vip;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Base64;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import android.content.SharedPreferences;

public class MainActivity extends Activity {

    private WebView webView;
    private static final String HOME = "https://vip.009.global/profile/";
    private static final String LOGIN_HOST = "vip.009.global";

    private static final String PREFS = "009_secure_login";
    private static final String PREF_CIPHER = "credentials_cipher";
    private static final String PREF_IV = "credentials_iv";
    private static final String KEY_ALIAS = "009_login_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setSaveFormData(true);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new LoginBridge(), "AndroidLogin");

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                if (url != null && url.startsWith("https://" + LOGIN_HOST)) {
                    injectRememberLoginScript(view);
                }
            }
        });

        webView.loadUrl(HOME);
    }

    private void injectRememberLoginScript(WebView view) {
        String saved = loadCredentialsJson();
        if (saved == null) saved = "";

        String escaped = JSONObject.quote(saved);

        String js =
            "(function(){"
          + "try{"
          + "const savedRaw=" + escaped + ";"
          + "let saved=null;"
          + "if(savedRaw){try{saved=JSON.parse(savedRaw);}catch(e){}}"

          + "const pw=document.querySelector('input[type=password]');"
          + "if(!pw)return;"

          + "const form=pw.closest('form')||document.querySelector('form');"
          + "if(!form)return;"

          + "let user=form.querySelector('input[type=email],input[name*=user i],input[name*=account i],input[name*=login i],input[type=text]');"

          + "if(saved&&user&&saved.username){"
          + " user.value=saved.username;"
          + " user.dispatchEvent(new Event('input',{bubbles:true}));"
          + " user.dispatchEvent(new Event('change',{bubbles:true}));"
          + "}"
          + "if(saved&&saved.password){"
          + " pw.value=saved.password;"
          + " pw.dispatchEvent(new Event('input',{bubbles:true}));"
          + " pw.dispatchEvent(new Event('change',{bubbles:true}));"
          + "}"

          + "if(!form.dataset.remember009Bound){"
          + " form.dataset.remember009Bound='1';"
          + " form.addEventListener('submit',function(){"
          + "   try{"
          + "     const p=form.querySelector('input[type=password]');"
          + "     const u=form.querySelector('input[type=email],input[name*=user i],input[name*=account i],input[name*=login i],input[type=text]');"
          + "     if(u&&p&&u.value&&p.value){"
          + "       AndroidLogin.saveCredentials(String(u.value),String(p.value));"
          + "     }"
          + "   }catch(e){}"
          + " },true);"
          + "}"
          + "}catch(e){}"
          + "})();";

        view.evaluateJavascript(js, null);
    }

    public class LoginBridge {
        @JavascriptInterface
        public void saveCredentials(String username, String password) {
            try {
                JSONObject obj = new JSONObject();
                obj.put("username", username == null ? "" : username);
                obj.put("password", password == null ? "" : password);
                saveCredentialsJson(obj.toString());
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void clearCredentials() {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            sp.edit().clear().apply();
        }
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);

        if (ks.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        }

        KeyGenerator kg = KeyGenerator.getInstance("AES", "AndroidKeyStore");
        android.security.keystore.KeyGenParameterSpec spec =
            new android.security.keystore.KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT |
                android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            )
            .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .build();

        kg.init(spec);
        return kg.generateKey();
    }

    private void saveCredentialsJson(String plainText) {
        try {
            SecretKey key = getOrCreateKey();
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key);

            byte[] iv = cipher.getIV();
            byte[] encrypted = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));

            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            sp.edit()
              .putString(PREF_CIPHER, Base64.encodeToString(encrypted, Base64.NO_WRAP))
              .putString(PREF_IV, Base64.encodeToString(iv, Base64.NO_WRAP))
              .apply();
        } catch (Exception ignored) {}
    }

    private String loadCredentialsJson() {
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            String c = sp.getString(PREF_CIPHER, null);
            String i = sp.getString(PREF_IV, null);

            if (c == null || i == null) return null;

            byte[] encrypted = Base64.decode(c, Base64.NO_WRAP);
            byte[] iv = Base64.decode(i, Base64.NO_WRAP);

            SecretKey key = getOrCreateKey();
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));

            byte[] plain = cipher.doFinal(encrypted);
            return new String(plain, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
