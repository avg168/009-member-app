009 會員中心｜Android + iPhone 一鍵發佈版 V2

目標：
只給會員「一個下載網址」。

Android：
- GitHub Actions 自動產生 APK
- APK 會自動放到下載首頁
- 會員點「下載 Android APK」即可下載

iPhone：
- 未設定 Apple Developer 時：Safari 開啟 / 加入主畫面
- 設定 Apple Developer 後：GitHub Actions 可建立 IPA
- 可選擇自動上傳 TestFlight
- 有 TestFlight 公開網址後，只要填到 public/config.js

GitHub 上傳方式：
1. 建立一個新的 GitHub Repository
2. 將本 ZIP 解壓縮後，全部內容上傳到 Repository 根目錄
3. GitHub → Settings → Pages
4. Source 選「GitHub Actions」
5. GitHub → Actions → Build Android APK and Publish → Run workflow
6. 執行完成後，GitHub Pages 會提供一個網址
7. 把這個網址直接發給會員即可

Android APK：
第一次 workflow 完成後，
public/009-Android.apk 會由建置流程自動建立並部署。
GitHub Actions 也會保留一份名為「009-Android-APK」的 Artifact。

iPhone TestFlight：
Apple Developer 資料設定完成後，
執行「Build iOS / TestFlight」。
取得 TestFlight 公開連結後，修改：

public/config.js

把：
testFlightUrl: ""

改成：
testFlightUrl: "您的 TestFlight 公開連結"

之後再執行 Android/Pages workflow，
iPhone 按鈕就會自動變成「使用 TestFlight 安裝」。

重要：
Android 使用 APK；iPhone 使用 Apple 簽章 IPA / TestFlight。
無法用同一個安裝檔同時安裝兩種系統，
但可以完全使用「同一個下載網址」自動分流。
