window.APP_CONFIG = {
  appName: "009 會員中心",
  profileUrl: "https://vip.009.global/profile/",
  androidApkUrl: "./009-Android.apk",
  testFlightUrl: "",
  version: "V3"
};
