import SwiftUI
import WebKit
import Security

struct ContentView: View {
    var body: some View {
        WebView()
            .ignoresSafeArea()
    }
}

struct WebView: UIViewRepresentable {
    private let homeURL = URL(string: "https://vip.009.global/profile/")!

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.userContentController.add(context.coordinator, name: "loginBridge")

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        context.coordinator.webView = webView

        webView.allowsBackForwardNavigationGestures = true
        webView.scrollView.contentInsetAdjustmentBehavior = .never

        let request = URLRequest(url: homeURL)
        webView.load(request)
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
        weak var webView: WKWebView?

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            guard let host = webView.url?.host, host == "vip.009.global" else { return }
            injectRememberLoginScript(webView)
        }

        private func injectRememberLoginScript(_ webView: WKWebView) {
            let creds = KeychainStore.load()
            let username = creds?.username ?? ""
            let password = creds?.password ?? ""

            func jsQuote(_ s: String) -> String {
                let data = try? JSONSerialization.data(withJSONObject: [s])
                let arr = data.flatMap { String(data: $0, encoding: .utf8) } ?? "[\"\"]"
                return String(arr.dropFirst().dropLast())
            }

            let js = """
            (function(){
              try {
                const savedUser = \(jsQuote(username));
                const savedPass = \(jsQuote(password));

                const pw = document.querySelector('input[type=password]');
                if (!pw) return;

                const form = pw.closest('form') || document.querySelector('form');
                if (!form) return;

                const user = form.querySelector(
                  'input[type=email],input[name*=user i],input[name*=account i],input[name*=login i],input[type=text]'
                );

                if (user && savedUser) {
                  user.value = savedUser;
                  user.dispatchEvent(new Event('input',{bubbles:true}));
                  user.dispatchEvent(new Event('change',{bubbles:true}));
                }

                if (savedPass) {
                  pw.value = savedPass;
                  pw.dispatchEvent(new Event('input',{bubbles:true}));
                  pw.dispatchEvent(new Event('change',{bubbles:true}));
                }

                if (!form.dataset.remember009Bound) {
                  form.dataset.remember009Bound = '1';
                  form.addEventListener('submit', function() {
                    try {
                      const p = form.querySelector('input[type=password]');
                      const u = form.querySelector(
                        'input[type=email],input[name*=user i],input[name*=account i],input[name*=login i],input[type=text]'
                      );
                      if (u && p && u.value && p.value) {
                        window.webkit.messageHandlers.loginBridge.postMessage({
                          action: 'save',
                          username: String(u.value),
                          password: String(p.value)
                        });
                      }
                    } catch(e) {}
                  }, true);
                }
              } catch(e) {}
            })();
            """

            webView.evaluateJavaScript(js)
        }

        func userContentController(_ userContentController: WKUserContentController,
                                   didReceive message: WKScriptMessage) {
            guard message.name == "loginBridge",
                  let body = message.body as? [String: Any],
                  let action = body["action"] as? String else { return }

            if action == "save",
               let username = body["username"] as? String,
               let password = body["password"] as? String {
                KeychainStore.save(username: username, password: password)
            } else if action == "clear" {
                KeychainStore.clear()
            }
        }
    }
}

struct Credentials: Codable {
    let username: String
    let password: String
}

enum KeychainStore {
    private static let service = "global.009.vip"
    private static let account = "009-login"

    static func save(username: String, password: String) {
        let creds = Credentials(username: username, password: password)
        guard let data = try? JSONEncoder().encode(creds) else { return }

        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]

        SecItemDelete(query as CFDictionary)

        var add = query
        add[kSecValueData as String] = data
        add[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(add as CFDictionary, nil)
    }

    static func load() -> Credentials? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess,
              let data = result as? Data else { return nil }

        return try? JSONDecoder().decode(Credentials.self, from: data)
    }

    static func clear() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}
