009 會員中心 iOS V1.1

新增：
- GitHub Actions 自動驗證 iOS 編譯
- GitHub Actions 自動 Archive
- 自動匯出 IPA
- 可選擇自動上傳 TestFlight
- 保留 V1.0 Keychain 記住帳號密碼功能

專案入口：
009VIP.xcodeproj

GitHub workflow：
.github/workflows/build-ios.yml

詳細設定：
GITHUB-自動建置與TestFlight設定.txt
