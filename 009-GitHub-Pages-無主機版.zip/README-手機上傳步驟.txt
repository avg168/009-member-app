009 GitHub Pages 無主機版

用途：
iPhone：GitHub Pages → Safari → 分享 → 加入主畫面
Android：可繼續使用 APK。

上傳到 GitHub Repository：
avg168/009-member-app

建議把本包內 index.html、manifest.webmanifest、sw.js、icons 資料夾放到 public 資料夾。
若現有 public 已有檔案，請先保留備份。

GitHub Pages 網址啟用後，iPhone 必須從 GitHub Pages 網址加入主畫面。
加入後桌面名稱：009 會員中心
點「進入 009 會員中心」會前往：
https://vip.009.global/profile/

注意：
因 vip.009.global 是另一個網域，GitHub Pages 的 PWA 無法把該會員頁本身變成同網域的全螢幕 PWA；此版本是獨立的 009 App 入口。
